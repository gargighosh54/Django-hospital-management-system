from django.shortcuts import render,get_object_or_404
from django.http import HttpRequest,HttpResponse,JsonResponse
from django.db.models import QuerySet
from django.template.loader import render_to_string
from .models import Hospital_record

def home(request:HttpRequest) -> HttpResponse:
    msg1: str = "Welcome to a place where care meets compassion.🏥"

    # Get existing session value
    visit_count = request.session.get("visit_count", 0)
    visit_count += 1
    # Store value in session
    request.session["visit_count"] = visit_count
    return render(request,"base.html",{"message" : msg1, "visit_count": visit_count})


def hospital_list(request: HttpRequest) -> HttpResponse:
    hospital_records: QuerySet = Hospital_record.objects.all()                    # ORM (ModelName Data Adapter which connects the ORM)
    return render(request,'add_data.html',{'hospital_records': hospital_records})               # HttpResponse
    
def add_data(request: HttpRequest):
    if request.method == 'POST':
        patient_name: str = request.POST['patient_name']
        patient_age:int =int(request.POST['patient_age'])
        patient_gender: str = request.POST['patient_gender']
        patient_phone_no:int =int(request.POST['patient_phone_no'])
        patient_disease: str = request.POST['patient_disease']
        doctor_name: str = request.POST['doctor_name']
        specialization: str = request.POST['specialization']
        patient_report: str = request.POST['patient_report']
        patient_report_result: str = request.POST['patient_report_result']

        if patient_name:
            if not Hospital_record.objects.filter(patient_name=patient_name).exists():   #Hospital_record= class, object= like bridge
                Hospital_record.objects.create(
                    patient_name=patient_name,
                    patient_age=patient_age,
                    patient_gender=patient_gender,
                    patient_phone_no=patient_phone_no,
                    patient_disease=patient_disease,
                    doctor_name=doctor_name,
                    specialization=specialization,
                    patient_report=patient_report,
                    patient_report_result=patient_report_result)
                # Updated list after saving new Stream
                hospital_records: QuerySet = Hospital_record.objects.all()
                # TypeError: Object of type QuerySet is not JSON serializable
                html_string = render_to_string("data_rows.html", {"hospital_records": hospital_records})
                return JsonResponse({"hospital_records": html_string, "message": "Data added successfully"}, status=201)     # go to success in script.js
            else:
                return JsonResponse({"message":"Data already exist"}, status = 400)
        else:
            return JsonResponse({
                "success": True,
                "message":"Patient name should be provided"}, status= 400)
    else:        
        return render(request,'add_data.html')

def edit(request:HttpRequest,id:int):
    if request.method == "POST":
        patient_name: str = request.POST['patient_name']
        patient_age:int =int(request.POST['patient_age'])
        patient_gender: str = request.POST['patient_gender']
        patient_phone_no:int =int(request.POST['patient_phone_no'])
        patient_disease: str = request.POST['patient_disease']
        doctor_name: str = request.POST['doctor_name']
        specialization: str = request.POST['specialization']
        patient_report: str = request.POST['patient_report']
        patient_report_result: str = request.POST['patient_report_result']

        if not Hospital_record.objects.filter(patient_name=patient_name).exclude(id=id).exists():
            patient = Hospital_record.objects.get(pk=id)
            patient.patient_name=patient_name
            patient.patient_age=patient_age
            patient.patient_gender=patient_gender
            patient.patient_phone_no=patient_phone_no
            patient.patient_disease=patient_disease
            patient.doctor_name=doctor_name
            patient.specialization=specialization
            patient.patient_report=patient_report
            patient.patient_report_result=patient_report_result

            patient.save()
            hospital_records :QuerySet= Hospital_record.objects.all()
            html_string = render_to_string("data_rows.html", {"hospital_records": hospital_records})
            return JsonResponse({"hospital_records": html_string, "message": "Data edited successfully."}, status=201)

def delete(request:HttpRequest,id:int):
    if request.method=="POST":
        patient=get_object_or_404(Hospital_record,pk=id)
        patient.delete()
        hospital_records :QuerySet =Hospital_record.objects.all()
        html_string = render_to_string("data_rows.html", {"hospital_records": hospital_records})
        return JsonResponse({"hospital_records": html_string, "message": "Data deleted successfully"}, status=200)
        







