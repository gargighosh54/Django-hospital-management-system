
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home, name= "home"),
    path("hospital/",views.hospital_list, name='hospital_list'),
    path('add/',views.add_data, name='add_data'),
    path('edit/<int:id>/',views.edit, name='edit'),
    path('delete/<int:id>/', views.delete, name='delete')
]
