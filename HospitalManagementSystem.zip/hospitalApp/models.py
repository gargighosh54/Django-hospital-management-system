from django.db import models

class Hospital_record(models.Model):
    patient_name = models.CharField(max_length=100)
    patient_age = models.IntegerField()
    patient_gender = models.CharField(max_length=20)
    patient_phone_no = models.IntegerField()
    patient_disease = models.CharField(max_length=200)

    doctor_name = models.CharField(max_length=100)
    specialization = models.CharField(max_length=100)

    patient_report = models.CharField(max_length=200)
    patient_report_result = models.TextField()
